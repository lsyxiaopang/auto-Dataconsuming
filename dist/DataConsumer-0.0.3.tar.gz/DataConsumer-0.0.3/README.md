# auto-Dataconsuming
 用于自动生成markdown图表
