from DataConsumer.RangeType import *
try:
    from DataConsumer.DataType import *
except:
    print("Warning:You may not use DataConsumer!")